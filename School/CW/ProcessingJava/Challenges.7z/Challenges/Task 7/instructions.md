# Task(s)

https://openprocessing.org/sketch/1140920

Notable items for this sketch include the following:
- The arrow keys move the black square around
- When you click the mouse within the bounds of the square, it changes fill to green while the mouse it held
- Any other time you click, nothing occurs

For an added challenge, ensure the square cannot leave the screen