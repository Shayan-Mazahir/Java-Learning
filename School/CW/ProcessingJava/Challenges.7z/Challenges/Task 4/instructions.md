# Task(s)

Create a sketch that is split into four quadrants. When hovering over a quadrant with the mouse, it should change colour to denote that it is being hovered over.

An example is shown in challenge4Task.gif