# Task(s)

Recreate rainbowCircles.gif using the colouring shown. You will need to use a different colour space to complete this task (HSB instead of RGB and you will need to use the remainder operator (%)).