# Task(s)

Recreate the behaviour in colorMouseBall.gif using the colours shown.