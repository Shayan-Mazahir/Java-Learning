# Task(s)

Create a sketch that is split into two halves (vertical line in the middle). Have an ellipse follow your mouse normally whenever it is on the left-hand side of the sketch, but when the mouse is on the right half, the circle should can only follow in a vertical direction.

an example is shown in challenge5Task.gif